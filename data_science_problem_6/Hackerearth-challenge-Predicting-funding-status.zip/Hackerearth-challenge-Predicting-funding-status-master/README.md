# Hackerearth challenge Predicting funding status

P.S - This is a hackerearth challenge problem and all the dataset was provided by hackerearth.
