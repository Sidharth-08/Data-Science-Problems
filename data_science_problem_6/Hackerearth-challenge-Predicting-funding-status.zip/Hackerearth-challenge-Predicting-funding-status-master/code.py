import csv
from datetime import datetime
import numpy as np
from pprint import pprint
import datetime
import time
from sklearn.preprocessing import MinMaxScaler
################################################################################


def targetFeatureSplit( data ):
    target = []
    features = []

    for item in data:

        new = item['goal'] * item['currency']
        #item['deadline_month'], item['launched_at_month'],

        features.append([ new, item['country'], item['goal'], item['currency']])
        target.append([item['final_status']])

    return target, features

################################################################################


currency=set()
country=set()

data_list=[]
features_test=[]
labels_test =[]
project_id=[]
with open("test.csv", "r") as data_file:
    data_dict = csv.DictReader(data_file)

    for line in data_dict:
        data_list.append(line)

    for row in data_list:
        currency.add(row['currency'])
        country.add(row['country'])

    temp_currency={}
    temp_country={}


    c_list=[]
    cc_currency={}
    with open("DP_LIVE_02112017192939286.csv", "r") as tfile:
        data_ict = csv.DictReader(tfile)

        for line in data_ict:
            c_list.append(line)

        for item in c_list:
            item['Value'] = float(item['Value'])
            cc_currency[item['LOCATION']] = item['Value']
        print cc_currency



    for item in currency:
        temp_currency[item] = cc_currency[item]

    for i, item in enumerate(country):
        temp_country[item] = i








    for item in data_list:
        if(item['disable_communication'] == 'false'):
            item['disable_communication'] = False
        else:
            item['disable_communication'] = True

        item['currency'] = temp_currency[item['currency']]
        item['country'] = temp_country[item['country']]

        item['goal'] = float(item['goal'])
        new = item['goal'] * item['currency']


        from datetime import datetime
        #dt = datetime.strptime(, '%w-%m-%d %H:%M:%S %Y')

        item['launched_at'] = time.ctime(int(item['launched_at']))
        item['launched_at_month'] = datetime.strptime(item['launched_at'], '%a %b %d %H:%M:%S %Y').month

        item['created_at'] = time.ctime(int(item['created_at']))
        item['created_at_month'] = datetime.strptime(item['created_at'], '%a %b %d %H:%M:%S %Y').month

        item['state_changed_at'] = time.ctime(int(item['state_changed_at']))
        item['state_changed_at_month'] = datetime.strptime(item['state_changed_at'], '%a %b %d %H:%M:%S %Y').month

        item['deadline'] = time.ctime(int(item['deadline']))
        item['deadline_month'] = datetime.strptime(item['deadline'], '%a %b %d %H:%M:%S %Y').month

        # item['deadline_month'], item['launched_at_month'],
        features_test.append([ new, item['country'], item['goal'], item['currency']])
        project_id.append(item['project_id'])


################################################################################



feature_list=['project_id', 'name', 'desc', 'goal', 'keywords', 'disable communication',
                    'country', 'currency', 'deadline', 'state_changed_at', 'created_at', 'launched_at','backers_count', 'final_status']

data_list=[]

with open("train.csv", "r") as data_file:
    data_dict = csv.DictReader(data_file)

    for line in data_dict:
        data_list.append(line)

    pprint(data_list[1])

    for row in data_list:
        row['backers_count'] = int(row['backers_count'])

        if(row['final_status'] == '0'):
            row['final_status'] = False
        else:
            row['final_status'] = True

        row['goal'] = float(row['goal'])

        if(row['disable_communication'] == 'false'):
            row['disable_communication'] = False
        else:
            row['disable_communication'] = True


        from datetime import datetime
        #dt = datetime.strptime(, '%w-%m-%d %H:%M:%S %Y')

        row['launched_at'] = time.ctime(int(row['launched_at']))
        row['launched_at_month'] = datetime.strptime(row['launched_at'], '%a %b %d %H:%M:%S %Y').month

        row['created_at'] = time.ctime(int(row['created_at']))
        row['created_at_month'] = datetime.strptime(row['created_at'], '%a %b %d %H:%M:%S %Y').month

        row['state_changed_at'] = time.ctime(int(row['state_changed_at']))
        row['state_changed_at_month'] = datetime.strptime(row['state_changed_at'], '%a %b %d %H:%M:%S %Y').month

        row['deadline'] = time.ctime(int(row['deadline']))
        row['deadline_month'] = datetime.strptime(row['deadline'], '%a %b %d %H:%M:%S %Y').month

        currency.add(row['currency'])
        country.add(row['country'])


    temp_currency={}
    temp_country={}
    c_list=[]
    cc_currency={}
    with open("DP_LIVE_02112017192939286.csv", "r") as tfile:
        data_ict = csv.DictReader(tfile)

        for line in data_ict:
            c_list.append(line)

        for item in c_list:
            item['Value'] = float(item['Value'])
            cc_currency[item['LOCATION']] = item['Value']
        print cc_currency



    for item in currency:
        temp_currency[item] = cc_currency[item]
    print '--------------------------------------------------'
    print temp_currency

    for i, item in enumerate(country):
        temp_country[item] = i


    print '-------------'

    for row in data_list:
        row['currency'] = temp_currency[row['currency']]
        row['country'] = temp_country[row['country']]

    print '-------------'

    pprint(data_list[1])

################################################################################

labels, features = targetFeatureSplit(data_list)


from sklearn.linear_model import Ridge
lr = Ridge()


from sklearn.naive_bayes import GaussianNB                                      # accuracy = 0.466
nb = GaussianNB()


from sklearn.svm import SVC
svc = SVC()

from sklearn.tree import DecisionTreeClassifier
dt = DecisionTreeClassifier()


from sklearn.ensemble import BaggingClassifier                                  # accuracy = 0.55850
bagging = BaggingClassifier(n_estimators = 1500)


from sklearn.ensemble import AdaBoostClassifier
adaboost = AdaBoostClassifier(algorithm = 'SAMME.R', n_estimators = 1000)


from sklearn.neural_network import MLPClassifier
ann = MLPClassifier()

clf = adaboost
clf.fit(features, labels)
predictions = clf.predict(features_test)


################################################################################
with open('output.csv', 'w') as csvfile:
    spamwriter = csv.writer(csvfile, delimiter=',')
    spamwriter.writerow(['project_id'] + ['final_status'])
    temp=[]
    for item in predictions:
        if(item == False):
            temp.append('0')
        else:
            temp.append('1')

    i=0
    for item in project_id:
        spamwriter.writerow([item]+[temp[i]])
        i+=1
